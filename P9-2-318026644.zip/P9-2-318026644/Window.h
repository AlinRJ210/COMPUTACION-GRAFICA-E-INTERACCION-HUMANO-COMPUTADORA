#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	GLfloat getXChange();
	GLfloat getYChange();
	GLfloat getmuevex() { return muevex; }
	GLfloat getmuevexhel() { return helmuevexhel; }
	GLfloat getlampoff() { return lamparaoff; }
	GLfloat getonoff() { return onoff; }
	GLfloat getonposneg() { return onposneg; }
	GLfloat getonnegative() { return onnegative; }
	GLfloat getarticulacion4() { return articulacion4; }
	GLfloat getarrancar() { return arrancar; }
	GLfloat getarrancar2() { return arrancar2; }
	GLfloat getaleteo() { return aleteo;  }
	GLfloat gettexturas() { return texturas_run; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	
	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	void createCallbacks();
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	GLfloat muevex;
	GLfloat helmuevexhel;
	GLfloat lamparaoff;
	GLfloat onoff;
	GLfloat onposneg;
	GLfloat onnegative; 
	GLfloat articulacion4;
	GLfloat arrancar; 
	GLfloat arrancar2;
	GLfloat aleteo;
	GLfloat texturas_run;
	bool mouseFirstMoved;
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);

	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);

};

